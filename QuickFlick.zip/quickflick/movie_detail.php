<?php
include 'db.php';

if (!isset($_GET['id'])) {
    echo "No movie selected.";
    exit();
}

$movie_id = intval($_GET['id']);

$query = "
    SELECT 
        movie.*, 
        studio.studio_name, 
        studio.studio_location
    FROM 
        movie
    LEFT JOIN 
        studio ON movie.studio_id = studio.studio_id
    WHERE 
        movie.movie_id = ?
";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $movie_id);
$stmt->execute();
$result = $stmt->get_result();
$movie = $result->fetch_assoc();

if (!$movie) {
    echo "Movie not found.";
    exit();
}

// Fetch genres
$query_genres = "SELECT genre.genre_name 
                 FROM movie_genre 
                 JOIN genre ON movie_genre.genre_id = genre.genre_id 
                 WHERE movie_genre.movie_id = ?";
$stmt_genres = $conn->prepare($query_genres);
$stmt_genres->bind_param("i", $movie_id);
$stmt_genres->execute();
$result_genres = $stmt_genres->get_result();
$genres = [];
while ($row = $result_genres->fetch_assoc()) {
    $genres[] = $row['genre_name'];
}

// Fetch cast
$query_cast = "SELECT person.person_name, movie_cast.character_name 
               FROM movie_cast 
               JOIN person ON movie_cast.person_id = person.person_id 
               WHERE movie_cast.movie_id = ?";
$stmt_cast = $conn->prepare($query_cast);
$stmt_cast->bind_param("i", $movie_id);
$stmt_cast->execute();
$result_cast = $stmt_cast->get_result();
$cast = [];
while ($row = $result_cast->fetch_assoc()) {
    $cast[] = $row;
}

//Fetch votes
$movie_id = intval($_GET['id']);
$sql = "SELECT * FROM movie WHERE movie_id = $movie_id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $movie = $result->fetch_assoc();
    $votes_avg = number_format($movie['votes_avg'], 1); // e.g., 7.1
    $votes_count = $movie['votes_count'];               // e.g., 223690
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Movie Detail - QuickFlick</title>
  <link rel="stylesheet" href="assets/style.css">
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 0;
      background-color: #f0f2f5;
      color: #333;
    }
    header {
      background-color:rgb(55, 118, 181);
      padding: 20px 40px;
      color: white;
      display: flex;
      justify-content: space-between;
      align-items: center;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    header h1 {
      margin: 0;
      font-size: 26px;
      color: white;
    }
    nav a {
      color: white;
      margin-left: 20px;
      text-decoration: none;
      font-weight: 500;
      transition: color 0.3s;
    }
    nav a:hover {
      color:rgb(0, 0, 0);
    }

    main {
      padding: 30px;
    }
    .movie-detail {
      background-color: white;
      padding: 20px;
      border-radius: 10px;
      max-width: 800px;
      margin: auto;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }
    .movie-poster {
      text-align: center;
      margin-bottom: 20px;
    }
    .movie-poster img {
      border-radius: 8px;
    }
    .poster-img {
      max-height: 400px;
      width: auto;
      height: auto;
      object-fit: contain;
      display: block;
      margin: auto;
    }
    h2 {
      text-align: center;
      margin-bottom: 20px;
    }
    /* .info {
      line-height: 1.8;
    } */


    .info {
        background: linear-gradient(135deg, #f0f9ff, #dbeafe);
        border-radius: 12px;
        padding: 20px;
        box-shadow: 0 6px 12px rgba(0,0,0,0.1);
        font-family: 'Segoe UI', sans-serif;
        color: #333;
        line-height: 1.7;
        margin-top: 20px;
    }

    .info ul {
        list-style-type: none;
        padding-left: 0;
        margin-bottom: 16px;
    }

    .info li {
        margin-left: 10px;
        position: relative;
        padding-left: 20px;
    }

    .info li::before {
        position: absolute;
        left: 0;
    }


    .back-link {
      display: block;
      text-align: center;
      margin-top: 30px;
      color: #007bff;
      text-decoration: none;
    }
    .back-link:hover {
      text-decoration: underline;
    }
  </style>

</head>
<body>

<header>
    <h1>🎬 QuickFlick</h1>
    <nav>
      <a href="index.php">Home</a>
      <a href="add.php">Add Movies</a>
      <a href="movies.php">View Movies</a>
    </nav>
    
</header>


<main>
  <div class="movie-detail">
    <div class="movie-poster">
      <?php if (!empty($movie['poster'])): ?>
        <img src="<?php echo htmlspecialchars($movie['poster']); ?>" alt="Movie Poster" class="poster-img">
      <?php else: ?>
        <p>No poster available.</p>
      <?php endif; ?>
    </div>

    <h2><?php echo htmlspecialchars($movie['title']); ?></h2>

    <div class="info">
      <?php if (!empty($genres)): ?>
        <p><strong>Genres:</strong> <?php echo htmlspecialchars(implode(", ", $genres)); ?></p>
      <?php endif; ?>

      <?php if (!empty($cast)): ?>
        <p><strong>Cast:</strong></p>
        <ul>
          <?php foreach ($cast as $member): ?>
            <li><?php echo htmlspecialchars($member['person_name']); ?> as <?php echo htmlspecialchars($member['character_name']); ?></li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>    
        <p><strong>Release Date:</strong> <?php echo htmlspecialchars($movie['release_date']); ?></p>
        <p><strong>Budget:</strong> $<?php echo number_format($movie['budget']); ?></p>
        <p><strong>Revenue:</strong> $<?php echo number_format($movie['revenue']); ?></p>
        <p><strong>Runtime:</strong> <?php echo htmlspecialchars($movie['runtime']); ?> minutes</p>
        <p><strong>Status:</strong> <?php echo htmlspecialchars($movie['status']); ?></p>
        <p><strong>Average Rating:</strong> <?php echo number_format($movie['votes_avg'], 1); ?> / 10</p>
        <p><strong>Total Votes:</strong> <?php echo number_format($movie['votes_count']); ?></p>

      <?php if (!empty($movie['studio_name'])): ?>
        <p><strong>Studio:</strong> <?php echo htmlspecialchars($movie['studio_name']); ?> (<?php echo htmlspecialchars($movie['studio_location']); ?>)</p>
      <?php endif; ?>
    </div>

    

    <div style="text-align: center; margin-top: 20px;">
      <h3>Rate this Movie</h3>
      <form action="submit_review.php" method="POST" style="margin-top: 10px;">
        <input type="hidden" name="movie_id" value="<?php echo $movie_id; ?>">
        <select name="rating" required style="padding: 8px 12px; border-radius: 5px; border: 1px solid #ccc;">
        <option value="">Select rating</option>
        <?php for ($i = 1; $i <= 10; $i++): ?>
          <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
        <?php endfor; ?>
        </select>
        <button type="submit" style="padding: 8px 15px; margin-left: 10px; background-color: #28a745; color: white; border: none; border-radius: 5px; cursor: pointer;">Submit
        </button>
      </form>
    </div>  

    <a href="movies.php" class="back-link">← Back to Movies</a>
  </div>
</main>

</body>
</html>